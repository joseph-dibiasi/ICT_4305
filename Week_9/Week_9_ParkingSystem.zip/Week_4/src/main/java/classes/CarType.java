package classes;

public enum CarType {

	SUV, COMPACT;
	
}
